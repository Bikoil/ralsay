# Ralsay - A silly CLI tool like cowsay
Ever wondered what would happen if ralsei and cowsay merged together? no? well then you get ralsay
borrowed the idea from a friend in discord lol
